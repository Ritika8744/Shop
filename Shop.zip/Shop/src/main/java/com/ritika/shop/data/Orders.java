package com.ritika.shop.data;

import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;

@Data
@Entity
@Table(name="ORDERS")
public class Orders
{
    @Id
    @Column(name = "ORDER_ID")
    private Long orderId;

    @Column(name = "ORDER_NAME")
    private String orderName;

    @Column(name = "QUANTITY")
    private BigDecimal quantity;

    @Column(name = "CUSTOMER_ID")
    private Long customerId;

    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;
}
