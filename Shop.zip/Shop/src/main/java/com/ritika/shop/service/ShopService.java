package com.ritika.shop.service;

import com.ritika.shop.model.QuantityResponse;

import javax.security.auth.login.AccountNotFoundException;

public interface ShopService
{
    QuantityResponse viewOrderQuantity(Long orderId) throws AccountNotFoundException;
}
