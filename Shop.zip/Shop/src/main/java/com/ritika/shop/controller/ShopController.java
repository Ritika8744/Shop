package com.ritika.shop.controller;

import com.ritika.shop.model.QuantityResponse;
import com.ritika.shop.service.impl.ShopServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.security.auth.login.AccountNotFoundException;

@RestController
@RequestMapping("/api/v1")

public class ShopController
{
    private static final Logger LOG = LoggerFactory.getLogger(ShopController.class.getName());

    private static final String RESPONSE_MESSAGE = "Response sent successfully";

    @Autowired
    private ShopServiceImpl shopService;

    @GetMapping("/quantity")

    public ResponseEntity<QuantityResponse> quantity(@RequestHeader Long orderId) throws AccountNotFoundException {

        LOG.info("Requested /quantity >>> {}", orderId);

        QuantityResponse quantity = shopService.viewOrderQuantity(orderId);

        LOG.info(RESPONSE_MESSAGE);

        return ResponseEntity.ok().body(quantity);
    }

}

