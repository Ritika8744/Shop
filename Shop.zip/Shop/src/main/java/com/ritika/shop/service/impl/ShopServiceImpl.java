package com.ritika.shop.service.impl;

import com.ritika.shop.data.Orders;
import com.ritika.shop.data.OrdersRepository;
import com.ritika.shop.model.QuantityResponse;
import com.ritika.shop.service.ShopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.security.auth.login.AccountNotFoundException;

@Service

public class ShopServiceImpl implements ShopService {
    @Autowired
    private OrdersRepository ordersRepository;

    private static final String RECORD_NOT_FOUND = "record does not exist";

    @Override
    public QuantityResponse viewOrderQuantity(Long orderId) throws AccountNotFoundException {

        Orders orders = ordersRepository.findById(orderId)
                .orElseThrow(() -> new AccountNotFoundException(RECORD_NOT_FOUND));

        return QuantityResponse.builder().orderId(orders.getOrderId()).quantity(orders.getQuantity())
                .build();

    }
}
